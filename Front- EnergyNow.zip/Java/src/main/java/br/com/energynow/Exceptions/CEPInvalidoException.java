package br.com.energynow.Exceptions;

public class CEPInvalidoException extends Exception{
    public CEPInvalidoException(){
        super("CEP Invalido");
    }
}
